<?php
  include 'insert.php';
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Log in</title>
<link href="logn.css" rel="stylesheet" type="text/css" />
<link href="https://fonts.googleapis.com/css?family=Play" rel="stylesheet">



</head>

<body>
   <div class="login">

<form action="logn.php" method="post">
<h2 style="color:#fff;">Log In</h2>
<input type="text" name="email" placeholder="Email address" required><br><br>  
<input type="password" name="password1" placeholder="Password" required><br/><br/>
<input type="submit" name="login_btn" value="Log In"></a><br/><br/>
<div id="container">
<a href="re.php" style=" margin-right:0px; font-size:13px; font-family:Tahoma, Geneva, sans-serif;">Reset password?</a>
    <a href="for.php " style=" margin-left:30px; font-size:13px; font-family:Tahoma, Geneva, sans-serif;">Forget password</a>
    <br><br>
Don't have account?<a href="sgnup.php" style="font-family:'Play', sans-serif;">&nbsp;Sign Up</a>

</form>

<?php
//coding

    if(isset($_POST['login_btn'])){
        
        $email= $_POST['email'];
        $password1=$_POST['password1'];
        
        $check = "select*from user where email='$email' AND pas ='$password1'";
        $check_work= mysqli_query($con,$check);
        
        if($check_work){
            if(mysqli_num_rows($check_work) > 0 ){
                
                echo"
                <script>
                alert('You are Successfully  Logged in');
                window.location.href='user.php';
                </script>
                ";
                
            }else{
                
                echo"
                <script>
                alert('Password or Email not Found ');
                window.location.href('logn.php');
                </script>
                ";
            }
            
            
        }else{
            
            
                echo"
                <script>
                alert('Database Error  ');
                window.location.href('logn.php');
                </script>
                ";
        }
        
        
        
    }else{
        
        
    }

?>

</div>



</body>
</html>

