<?php
$host ="localhost";
$name="root";
$password="";
$dbname="test";
$con = mysqli_connect($host,$name,$password) or die ('Unable to connect Database');
mysqli_select_db($con,$dbname);




?>



