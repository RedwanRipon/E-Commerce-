<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>E-Commers Website Single  Product</title>
    
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/responsive.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>

</head>

<body>
    <div class="top-nav-bar">
        <div class="search_box">
            <i class="fa fa-bars" id="menu-btn" onclick="openmenu()"></i>
            <i class="fa fa-times" id="close-btn " onclick="closemenu()"></i>
           <a href="index.html"><img src="image/Logo1.png" class="logo" height="95" width="150"></a>
            <input type="text" class="form-control">
            <span class="input-group-text"><i class="fa fa-search"></i></span>
        </div>
        <div class="menu_bar">
        <ul>
            <li><a href="cart.php"><i class="fa fa-shopping-cart"></i>cart</a></li>
            <li><a href="login/sgnup.html"><i class="fa fa-sign-in-alt"></i>sign up</a></li>
            <li><a href="login/logn.html"><i class="far fa-arrow-alt-circle-right"></i>log in</a></li>
        </ul>
    </div>
    </div>
    <!--------Single product--------------->
    <section class="single-product">
        <div class="container">
            <div class="row">
                <div class="col-md-5">
                    <div id="product-slider" class="carousel slide carousel-fade" data-ride="carousel">
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="image/product3.jpg" class="d-block w-100">
    </div>
    <div class="carousel-item">
      <img src="image/sh1.jpg" class="d-block w-100">
    </div>
    <div class="carousel-item">
      <img src="image/sh2.jpg" class="d-block w-100">
    </div>
    <div class="carousel-item">
      <img src="image/sh3.jpg" class="d-block w-100">
    </div>

   <a class="carousel-control-prev" href="#product-slider" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#product-slider" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
  </div>
  </div>
           </div>
           <div class="col-md-7">
                <p class="new-arrival text-center">New</p>
                <h2>Men's Shoes</h2>
                <p>Product Code: IRSH000119</p>

                <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star-half-o"></i>

                        <p class="price">USD $250.00</p>
                        <p><b>Availability:</b> In Stock</p>
                        <p><b>Condition:</b> New</p>
                        <p><b>Brand:</b> Hu'lulu Company</p>
                        <label>Quantity: </label>
                        <input type="text" value="1">
                        <label>Product Size: </label>
                        <input type="text" value="8"><br>
                        <button type="button" class="btn btn-primary">Add to Cart</button>
                        <button type="button" class="btn btn-primary">Buy Now</button>
                        
                   </div>               
            </div>           
        </div>
        
    </section>
    <!--------product-description------------------>
    <section class="product-description">
        <div class="container">
            <h6>Product Description</h6>
            <p>Fashionable and comfortable</p>
            <p>Brand :Bata<br>
              Color: Blue,Black<br>
              Sneaker Upper Height: Low<br>
              Main Material: Synthetic<br>
              Men Shoes Closure:Slip-on & Pull-on<br>
              Sneakers Style: Canvas Sneakers<br>
              Shoe Style: Basic</p>
            <p>Cotton fabric</p>
            <p>size: 8,9,10,11,12</p>
            <hr>

        </div>
     <div class="container">
            <div class="title-box"> 
                <h2>Similar</h2>
            </div>
            <div class="row">
                <div class="col-md-3">
                    <div class="product-top">
                        <img src="image/f1.jpg" height="250px" width="350px">
                        <div class="overlay-right">
                            <button type="button" class="btn btn-secondary" title="Quick Shop">
                                <i class="fa fa-eye"></i>                               
                            </button>
                            <button type="button" class="btn btn-secondary" title="Add to Wishlist">
                                <i class="fa fa-heart-o"></i>                               
                            </button>
                            <button type="button" class="btn btn-secondary" title="Add to cart">
                                <i class="fa fa-shopping-cart"></i>                             
                            </button>

                            
                        </div>
                        
                    </div>
                    <div class="product-bottom text-center">
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star-half-o"></i>
                        <h3>Furniture</h3>
                        <h5>$4000.75</h5> 
                        
                    </div>
                    
                </div>

                <div class="col-md-3">
                    <div class="product-top">
                        <img src="image/f2.jpg" height="250px" width="350px">
                        <div class="overlay-right">
                            <button type="button" class="btn btn-secondary" title="Quick Shop">
                                <i class="fa fa-eye"></i>                               
                            </button>
                            <button type="button" class="btn btn-secondary" title="Add to Wishlist">
                                <i class="fa fa-heart-o"></i>                               
                            </button>
                            <button type="button" class="btn btn-secondary" title="Add to cart">
                                <i class="fa fa-shopping-cart"></i>                             
                            </button>

                            
                        </div>
                        
                    </div>
                    <div class="product-bottom text-center">
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star-"></i>
                        <h3>Laptop</h3>
                        <h5>$5000.00</h5> 

                    </div>
                </div>

                <div class="col-md-3">
                    <div class="product-top">
                        <img src="image/f3.jpg" height="250px" width="350px">
                        <div class="overlay-right">
                            <button type="button" class="btn btn-secondary" title="Quick Shop">
                                <i class="fa fa-eye"></i>                               
                            </button>
                            <button type="button" class="btn btn-secondary" title="Add to Wishlist">
                                <i class="fa fa-heart-o"></i>                               
                            </button>
                            <button type="button" class="btn btn-secondary" title="Add to cart">
                                <i class="fa fa-shopping-cart"></i>                             
                            </button>

                            
                        </div>
                        
                    </div>
                    <div class="product-bottom text-center">
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star-"></i>
                        <h3>Body Lotion</h3>
                        <h5>$250.00</h5>    

                    </div>
                </div>
                <div class="col-md-3">
                    <div class="product-top">
                        <img src="image/f4.jpg" height="250px" width="350px">
                        <div class="overlay-right">
                            <button type="button" class="btn btn-secondary" title="Quick Shop">
                                <i class="fa fa-eye"></i>                               
                            </button>
                            <button type="button" class="btn btn-secondary" title="Add to Wishlist">
                                <i class="fa fa-heart-o"></i>                               
                            </button>
                            <button type="button" class="btn btn-secondary" title="Add to cart">
                                <i class="fa fa-shopping-cart"></i>                             
                            </button>

                            
                        </div>
                        
                    </div>
                    <div class="product-bottom text-center">
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star"></i>
                        <i class="fa fa-star-"></i>
                        <h3>Car</h3>
                        <h5>$50000.00</h5>    

                    </div>
                </div>               
            </div>
    </div>

    </section>
<!--------Footer--------------->
    <section class="footer">
    <div class="container text-center">
        <div class="row">
            <div class="col-md-3">
                <h1>Useful Links</h1>
                <p>Privacy Policy</p>
                <p>Terms of Use</p>
                <p>Return Policy</p>
                <p>Discount Coupons</p>
                
            </div>

            <div class="col-md-3">
                <h1>Company</h1>
                <p>About Us</p>
                <p>Contact Us</p>
                <p>Carrer</p>
                <p>Affiliate</p>
        
            </div>

            <div class="col-md-3">
                <h1>Follow Us On</h1>
                <p><i class="fa fa-facebook-official"></i>
                Facebook</p>
                <p><i class="fa fa-youtube-play"></i> Youtube</p>
                <p><i class="fa fa-twitter"></i> Twitter</p>
                <p><i class="fa fa-linkedin"></i> Linkedin</p>
                
            </div>

            <div class="col-md-3 footer-image">
                <h1>Download App</h1>
                <img src="image/app-logo1.png" height="90px" width="190px">
            </div>
        </div>

        <hr>
        <p class="copyright">Made with <i class="fa fa-heart-o"></i> by Southeast University</p>
    </div>
    
</section>

    <script >
        function openmenu()
        {
            document.getElementById("side-menu").style.display="block";
            document.getElementById("menu-btn").style.display="none";
            document.getElementById("close-btn").style.display="block";
        }
        function closemenu()
        {
            document.getElementById("side-menu").style.display="none";
            document.getElementById("menu-btn").style.display="block";
            document.getElementById("close-btn").style.display="none";
        }
        
    </script>
</body>
</html>